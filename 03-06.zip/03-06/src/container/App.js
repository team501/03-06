/**
 * App.js Layout Start Here
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect, Route } from 'react-router-dom';
import { NotificationContainer } from 'react-notifications';

// Login Page
import Login from '../components/Login/Login';

//Landing Page
import LandingPage from '../components/LandingPage/LandingPage';

// rct theme provider
import RctThemeProvider from './RctThemeProvider';

//Horizontal Layout
import HorizontalLayout from './HorizontalLayout';

//Agency Layout
import AgencyLayout from './AgencyLayout';

//Main App
import RctDefaultLayout from './DefaultLayout';

// boxed layout
import RctBoxedLayout from './RctBoxedLayout';

/**
 * Initial Path To Check Whether User Is Logged In Or Not
 */
const InitialPath = ({ component: Component, ...rest, authUser }) => {

	return <Route
		{...rest}
		render={props =>
			authUser
			? <Component {...props} />
			: <Redirect to={{
				pathname: '/login',
				state: { from: props.location }
			}}
		/>}
	/>;
}

/**
 * Login Path To Check Whether User Is Logged Out Or Not 
 * If Not Redirect to Landing Page on clicking browser's Back Button
 */
const LoginPath = ({ component: Component, ...rest, authUser }) => {
	
		return <Route
			{...rest}
			render={props =>
				!authUser
				? <Component {...props} />
				: <Redirect to={{
					pathname: '/landingPage',
					state: { from: props.location }
				}}
			/>}
		/>;
	}

class App extends Component {
	render() {
		const { location, match, Validuser } = this.props;
		if (location.pathname === '/') {
		if(Validuser)
		{
		return <Redirect to={'/landingPage'} />;
		}else{
				return <Redirect to={'/login'} />;
				}
		}
		return (
			<RctThemeProvider>
				<NotificationContainer />
				<InitialPath
					path={`${match.url}app`}
					authUser={Validuser}
					component={HorizontalLayout}
				/>
				<InitialPath
					path={`/landingPage`}
					authUser={Validuser}
					component={LandingPage}
				/>

				<LoginPath
					path={`/login`}
					authUser={Validuser}
					component={Login}
				/>

				{/* <Route path="/login" component={Login} /> */}
				
				{/* <Route path="/landingPage" component={LandingPage} /> */}

			</RctThemeProvider>
		);
	}
}

// map state to props
const mapStateToProps = ({ authUser }) => {
	const { user } = authUser;
	let Validuser = (user !== null && user !== 'undefined' && user.trim() !== "") ? true : false ;
	return { Validuser };
};

export default connect(mapStateToProps)(App);
