/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

//json
import json from '../../assets/data/jsonDataConfig/UnitSorterMainDashboard/Sorter/sorterJson';
import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 
// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

import {Link} from 'react-router-dom';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import { graphQlURLPrd } from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';
import NumberClass from 'Util/NumberClass';

const headingGrid = {
		textAlign: 'left',
		height: '25px',
		fontSize: 'large',
		padding: '5px'
};

const headingGrid2 = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'medium',
		padding: '5px 5px 30px 5px'
};

const headingGrid3 = {
		height: '25px',
	    fontSize: 'medium',
		padding: '5px'
};

const bottomGrid = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'xx-large',
		padding: '5px'
};

const mainGrid = {
		padding: '25px',
		height: '170px',
};

const gridContent = {
		height: '40px',
		padding: '0px',
		fontSize: 'xx-large'	
};

class Sorters extends Component {

	constructor(props) {
		super(props);
		this.state = {	getUnitSorterDetails: [],
					    isLoading:true
					 };
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let query = `query GetUnitSorterDetails($startTime: Long!, $xMins: Int) {
						    	getUnitSorterDetails(startTime: $startTime, xMins: $xMins) {
									sorterId sorts inducts assignedPercent fullCount   
								}
					}`;
		
		let startTime = 201903231431;//dateFormat(new Date(), "yyyymmddHHMM");
		let xMins = 60;
		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, xMins }
			})
		})
		.then(r => r.json())
		.then(data => { 
			console.log("00000000000000000000000000000000000000000000000");
			console.log(data.data.getUnitSorterDetails);
			console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		    this.setState({ 
		    				getUnitSorterDetails: data.data.getUnitSorterDetails !== undefined && data.data.getUnitSorterDetails !== null ? data.data.getUnitSorterDetails : new Array(),
						    isLoading:false
						  }); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ 
							getUnitSorterDetails: [],
						    isLoading:false
						  }); 
		});
	}

	setBarColor = (percentage) => {
		if(percentage < 30) {
			return "danger";
		} else if(percentage >= 30 && percentage <=80) {
			return "warning";
		} else if(percentage > 80) {
			return "success";
		}
	} 

	render() {
	const { isColorBlind } = this.props;
		const sorters = (data) => {
			
			let inductGoal = 1;
			let sortGoal = 1;
			this.props.goal.map(element => {
				if(element.name === data.sorterId){ 
					inductGoal = element.inductGoalPerHour;
					sortGoal = element.sortsGoalPerHour;
					return element;
				};
			})
			
			
			let inductPercentage = parseInt((data.inducts/inductGoal) * 100) ;
			let sortsPercentage = parseInt((data.sorts/sortGoal) * 100);
			console.log("=---------------------------------------=");
			console.log(inductGoal+","+sortGoal);
			console.log("=---------------------------------------=");
			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={data.sorterId}
					fullBlock
					>
						<div className="clearfix">
		                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">  
		      
		                <Grid container>
						<Grid style={mainGrid} container spacing={24}>
							<Grid item xs={4} sm={4}>
							<Grid style={headingGrid2} item xs={12} sm={12}>
								{json.sorters.inductsForLastHr}
							</Grid>
								<Grid style={headingGrid2} item xs={12} sm={12}>
								
								
									
									{isColorBlind ? (
										<div className="unisorter_blind">
									<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(inductPercentage)} now={inductPercentage} />
									</div>
									  ) : (
										<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(inductPercentage)} now={inductPercentage} />
									  )}
									</Grid>
								
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {data.inducts} />
								</Grid>
							</Grid>
							
							<Grid item xs={4} sm={4}>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									{json.sorters.sortsForLastHr}
								</Grid>
							
								<Grid style={headingGrid2} item xs={12} sm={12}>
									{isColorBlind ? (
										<div className="unisorter_blind">
									<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(sortsPercentage)} now={sortsPercentage} />
									</div>
									  ) : (
										<ProgressBar style={{height: '5px'}} bsStyle={this.setBarColor(sortsPercentage)} now={sortsPercentage} />
									  )}
								</Grid>
						
								<Grid style={bottomGrid} item xs={12} sm={12}>
									<NumberClass  number= {data.sorts} />
								</Grid>
							</Grid>
						
							<Grid item xs={4} sm={4} >
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<div style={{float: 'left'}}>{json.sorters.chuteStatus}</div>
									
								</Grid>
								
								<Grid container spacing={24}>
									<Grid item xs={12} sm={6} style={{textAlign: 'center'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											{data.assignedPercent}%
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											{json.sorters.assigned}
										</Grid>
									</Grid>
									<Grid item xs={12} sm={4} style={{textAlign: 'center'}}>
										<Grid style={gridContent} item xs={12} sm={12}>
											<NumberClass  number= {data.fullCount} />
										</Grid>
										<Grid style={headingGrid3} item xs={12} sm={12}>
											{json.sorters.full}
										</Grid>
									</Grid>
									<Grid item xs={12} sm={2} className="right-arrow">
										<Link to={{ pathname: '/app/dashboard/sorterDetails', state: { data: data.sorterId } }}> &#x203A; </Link>
									</Grid>
									
								</Grid>
								
							</Grid>
							

							
						</Grid>	
					</Grid>
		           </div>
		            </div>
		        </RctCollapsibleCard>
			);
		}

		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={json.title}
										fullBlock > 
					</RctCollapsibleCard>);
		} else {
			return ( <React.Fragment>
						{ this.state.getUnitSorterDetails.map(data => sorters(data) ) }
					</React.Fragment> );
		}
		
	}
}


// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};


export default withRouter(connect(mapStateToProps)(Sorters));
