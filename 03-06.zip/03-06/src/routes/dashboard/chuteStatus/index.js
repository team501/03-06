/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import axios from 'axios';

import MUIDataTable from "mui-datatables";

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

// import Base URL from Config
import {baseURL} from '../../../services/Config';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

export default class chuteStatus extends Component {

    state = {  
        data: [],
        columns: {},
        colData: []
     };

    linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink; 

    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
    }
    

    // on reload fetch new data from data base
	onReload = () => {
		let tableData = [];
        axios.get(baseURL+'chutedetails/'+ localStorage.getItem("user_id") )
            .then(res => {
                //Data Extraxtion fro Reactify MUI DataTable
                for (let i = 0; i < res.data.length; i++) {
                    const row = res.data[i];
                    const tableColumns = ["Chute No.", "Full", "Disabled", "Duration", "Timestamp"];
                    tableData.push(
                        [
                           row.chute_nbr,
                            row.product_full,
                            row.product_disabled,
                            row.duration,
                            row.created_ts
                        ]
                    );
                    //Set Extracted Data in State
                    this.setState({ 
                        tableData: tableData,
                        tableColumns: tableColumns
                    });
                  }
                 
            }).catch(function (error) {
                console.log(error);
        });
    }


    getMuiTheme = () => createMuiTheme({
        overrides: {
                      MUIDataTableHeadCell : {
                                      root: {                                   
                                          padding: '4px 20px 4px 20px',     
                                          fontSize: '13px',
                                          color: 'black'                                         
                        }}, 
         
                      MUIDataTableBodyCell: {
                        root: {                                 
                                        padding: '4px 20px 4px 20px',
                                        fontSize: '12px'
                        }
                      },
                      MUIDataTableToolbar: {
                             root: {
                                display: 'none'
                            }
                        } 
        }
      })

    render() {
        const options = {
            filterType: 'dropdown',
            responsive: 'stacked',
            selectableRows: false // to remove the checkbox
        };
        return (
            <div className="data-table-wrapper">
                <PageTitleBar 
                    title={<IntlMessages id="sidebar.chuteStatusTable" />} 
                    match={this.props.match}
                    url="/app/dashboard/sorterDetails" 
                    urlState={this.linkState} 
                />
                {/* Card To hold Table */}
                <RctCard>
		            <RctCardContent>
                        <div className="contextual-link float-left chute-sub-header">
                            Chute Status
                        </div>
                        <div className="contextual-link float-right">
                            <i className=" refresh-button" onClick={() => this.onReload()}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8c-.45-.83-.7-1.79-.7-2.8 0-3.31 2.69-6 6-6zm6.76 1.74L17.3 9.2c.44.84.7 1.79.7 2.8 0 3.31-2.69 6-6 6v-3l-4 4 4 4v-3c4.42 0 8-3.58 8-8 0-1.57-.46-3.03-1.24-4.26z"/></svg></i>
                        </div> 
                        <MuiThemeProvider theme={this.getMuiTheme()}>
                        {/* Reactify Chute Status Data Table Start */}
                        <MUIDataTable
                            // title={"Chute Status Table"}
                            data={this.state.tableData}
                            columns={this.state.tableColumns}
                            options={options}
                        />
                        {/* Reactify Chute Status Data Table End */}
                        </MuiThemeProvider>
                    </RctCardContent>
			    </RctCard >
            </div>
        );
    }
}


