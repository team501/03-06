import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import { Label  } from 'react-bootstrap';
import NumberClass from './NumberClass';


import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom';  //will pass updated props to the wrapped component 

//json
import json from '../../../assets/data/jsonDataConfig/Sorter/chuteStatusJson';

const parentGrid = {
	    paddingTop: '5%'
};

const headingGrid = {
		paddingBottom: '20px',
		fontSize: 'larger',
};

const headingFont1 = {
		fontFamily: 'sans-serif',
		padding: '5px 0px'
};

const headingFont2 = {
		fontFamily: 'sans-serif',
	    fontSize: 'x-large'
};

const labelStyleFull= {
		padding: '5px 15px 15px 15px',
		float: 'left',
		 backgroundColor: json.chuteStatus.legends.labels.full.bgColor,
		 borderRadius: 'unset',
};
const labelStyleAvail= {
		padding: '5px 15px 15px 15px',
		float: 'left',
		 backgroundColor: json.chuteStatus.legends.labels.available.bgColor,
		 borderRadius: 'unset',
};
const labelStyleError= {
		padding: '5px 15px 15px 15px',
		float: 'left',
		 backgroundColor: json.chuteStatus.legends.labels.error.bgColor,
		 borderRadius: 'unset',
};
const labelStyleDisb= {
		padding: '5px 15px 15px 15px',
		float: 'left',
		 backgroundColor: json.chuteStatus.legends.labels.disabled.bgColor,
		 borderRadius: 'unset',
};


class index extends Component { 
	render() { 
	
		return (
				 <Grid style={parentGrid} container>
					 <Grid style={headingGrid} item xs={12} sm={12}>
					 	{json.chuteStatus.legends.title} - <span style={{fontSize:'25px'}}><strong> 
							 <NumberClass number={this.props.data.utilization} /> </strong></span>
			         </Grid>
					 	
					 <Grid container>
						 <Grid style={headingFont1} item xs={4} sm={4}>
						 	<Label style={labelStyleFull} >{' '}</Label> 
							 <div style={{float: 'left', paddingLeft: '5%'}}>{json.chuteStatus.legends.labels.full.text}</div>
				         </Grid>
						 <Grid style={headingFont2} item xs={8} sm={8}>
						 	<NumberClass number={this.props.data.chuteFull} /> - {this.props.data.fullPercentage} %
				         </Grid>
			         </Grid>
					 
					 <Grid container>
						 <Grid style={headingFont1} item xs={4} sm={4}>
						 <Label style={labelStyleAvail} className="warningLabel">{' '}</Label> <div style={{float: 'left',
							    															   paddingLeft: '5%'}}>{json.chuteStatus.legends.labels.available.text}</div>
				         </Grid>
						 <Grid style={headingFont2} item xs={8} sm={8}>
						 	<NumberClass number={this.props.data.empty} /> - {this.props.data.emptyPercentage} %
				         </Grid>
			         </Grid>
					 	
					 <Grid container>
						 <Grid style={headingFont1} item xs={4} sm={4}>
						 <Label style={labelStyleError} className="dangerLabel">{' '}</Label> <div style={{float: 'left',
							   																	paddingLeft: '5%'}}>{json.chuteStatus.legends.labels.error.text}</div> 
				         </Grid>
						 <Grid style={headingFont2} item xs={8} sm={8}>
						 	<NumberClass number={this.props.data.error} /> - {this.props.data.errorPercentage} %
				         </Grid>
			         </Grid>
					 	
					 <Grid container>
						 <Grid style={headingFont1} item xs={4} sm={4}>
						 <Label style={labelStyleDisb} className="defaultLabel">{' '}</Label> <div style={{float: 'left',
							   																	paddingLeft: '5%'}}>{json.chuteStatus.legends.labels.disabled.text}</div> 
				         </Grid>
						 <Grid style={headingFont2} item xs={8} sm={8}>
						 	<NumberClass number={this.props.data.disabled} /> - {this.props.data.disabledPercentage} %
				         </Grid>
			         </Grid>

				 </Grid>

		);}
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};

export default withRouter(connect(mapStateToProps)(index));